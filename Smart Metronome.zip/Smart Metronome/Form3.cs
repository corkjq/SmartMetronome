﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smart_Metronome
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void buttonToForm1_Click(object sender, EventArgs e) //Button takes you to main practice page
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        public void updateBackColour(String colour) 
        {
            switch (colour)
            {
                case "Black":
                    this.BackColor = Color.Black;
                    break;
                case "Blue":
                    this.BackColor = Color.Blue;
                    break;
                case "Green":
                    this.BackColor = Color.Green;
                    break;
                case "Orange":
                    this.BackColor = Color.Orange;
                    break;
                case "Red":
                    this.BackColor = Color.Red;
                    break;
                case "White":
                    this.BackColor = Color.White;
                    break;
                case "Yellow":
                    this.BackColor = Color.Yellow;
                    break;
            }
        }

        public void updateForeColour(String colour)
        {
            switch (colour)
            {
                case "Black":
                    this.ForeColor = Color.Black;
                    break;
                case "Blue":
                    this.ForeColor = Color.Blue;
                    break;
                case "Green":
                    this.ForeColor = Color.Green;
                    break;
                case "Orange":
                    this.ForeColor = Color.Orange;
                    break;
                case "Red":
                    this.ForeColor = Color.Red;
                    break;
                case "White":
                    this.ForeColor = Color.White;
                    break;
                case "Yellow":
                    this.ForeColor = Color.Yellow;
                    break;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
