﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;
using System.Threading;

namespace Smart_Metronome
{
    public partial class Form1 : Form
    {
        String dataIn, bpm, difficulty, length, settings;
        int time_left, convert_wait;
        double bpm_wait, wait_period, max_hits;

        public Form1()
        {
            InitializeComponent();
            getPorts();
            panel3.Visible = false;
        }

        private void getPorts() //Gets available serial ports
        {
            String[] ports = SerialPort.GetPortNames();
            portComboBox.Items.AddRange(ports);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void openButton_Click(object sender, EventArgs e) //Sets up connection to mbed board
        {
            try
            {
                if (portComboBox.Text == "" || bandComboBox.Text == "")
                {
                    textBox2.Text = "Please enter port values to connect to the port!";
                }
                else
                {
                    serialPort1.PortName = portComboBox.Text;
                    serialPort1.BaudRate = Convert.ToInt32(bandComboBox.Text);
                    serialPort1.Open();
                    progressBar1.Value = 100;
                    openButton.Enabled = false;
                    closeButton.Enabled = true;
                    sendButton.Enabled = true;
                }
            }
            catch (UnauthorizedAccessException)
            {
                textBox2.Text = "Unauthorized access!";
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void closeButton_Click(object sender, EventArgs e) //Closes serial connection to mbed board
        {
            serialPort1.Close();
            progressBar1.Value = 0;
            textBox2.Text = "";
            openButton.Enabled = true;
            closeButton.Enabled = false;
            sendButton.Enabled = false;
        }

        private void sendButton_Click(object sender, EventArgs e) //Sends settings to mbed board
        {
            if (comboBox4.Text == "Tempo/BPM")
            {
                switch (numericUpDown1.Value)
                {
                    case 60:
                        bpm = "a";
                        bpm_wait = 60;
                        break;
                    case 65:
                        bpm = "b";
                        bpm_wait = 65;
                        break;
                    case 70:
                        bpm = "c";
                        bpm_wait = 70;
                        break;
                    case 75:
                        bpm = "d";
                        bpm_wait = 75;
                        break;
                    case 80:
                        bpm = "e";
                        bpm_wait = 80;
                        break;
                    case 85:
                        bpm = "f";
                        bpm_wait = 85;
                        break;
                    case 90:
                        bpm = "g";
                        bpm_wait = 90;
                        break;
                    case 95:
                        bpm = "h";
                        bpm_wait = 95;
                        break;
                    case 100:
                        bpm = "i";
                        bpm_wait = 100;
                        break;
                    case 105:
                        bpm = "j";
                        bpm_wait = 105;
                        break;
                    case 110:
                        bpm = "k";
                        bpm_wait = 110;
                        break;
                    case 115:
                        bpm = "l";
                        bpm_wait = 115;
                        break;
                    case 120:
                        bpm = "m";
                        bpm_wait = 120;
                        break;
                }
            }
            else if (comboBox4.Text == "Pattern 1")
            {
                bpm = "n";
                bpm_wait = 90;
            }

            if (easy_button.Checked == true)
            {
                difficulty = "a";
            }
            else if (medium_button.Checked == true)
            {
                difficulty = "b";
            }
            else if (hard_button.Checked == true)
            {
                difficulty = "c";
            }

            switch (comboBox1.Text)
            {
                case "0.10":
                    length = "a";
                    time_left = 10;
                    break;
                case "0.50":
                    length = "b";
                    time_left = 30;
                    break;
                case "1":
                    length = "c";
                    time_left = 60;
                    break;
                case "5":
                    length = "d";
                    time_left = 300;
                    break;
                case "10":
                    length = "e";
                    time_left = 600;
                    break;
                case "15":
                    length = "f";
                    time_left = 900;
                    break;
            }

            settings = bpm + difficulty + length;
            serialPort1.WriteLine(settings);

            time_label.Text = time_left + " seconds";
            max_hits = time_left * (bpm_wait / 60);
            wait_period = (60 / bpm_wait) * 1000;
            convert_wait = Convert.ToInt32(wait_period);
            timer2.Interval = convert_wait;

            if (bpm == "n")
            {
                timer1.Start();
            }
            else
            {
                timer2.Start();
                System.Threading.Thread.Sleep(1000 + (convert_wait * 4));
                timer1.Start();
            }

        }

        private void readButton_Click(object sender, EventArgs e) //Displays info from board
        {
            try
            {
                textBox2.Text = serialPort1.ReadExisting();
            }
            catch(TimeoutException)
            {
                textBox2.Text = "Timeout!";
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e) //Displays info from board
        {
            dataIn = serialPort1.ReadExisting();
            this.Invoke(new EventHandler(showData));
        }

        private void portComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) //Appearance settings
        {
            switch (comboBox2.Text)
            {
                case "Black":
                    this.BackColor = Color.Black;
                    break;
                case "Blue":
                    this.BackColor = Color.Blue;
                    break;
                case "Green":
                    this.BackColor = Color.Green;
                    break;
                case "Orange":
                    this.BackColor = Color.Orange;
                    break;
                case "Red":
                    this.BackColor = Color.Red;
                    break;
                case "White":
                    this.BackColor = Color.White;
                    break;
                case "Yellow":
                    this.BackColor = Color.Yellow;
                    break;
            }

            switch (comboBox3.Text)
            {
                case "Black":
                    this.ForeColor = Color.Black;
                    break;
                case "Blue":
                    this.ForeColor = Color.Blue;
                    break;
                case "Green":
                    this.ForeColor = Color.Green;
                    break;
                case "Orange":
                    this.ForeColor = Color.Orange;
                    break;
                case "Red":
                    this.ForeColor = Color.Red;
                    break;
                case "White":
                    this.ForeColor = Color.White;
                    break;
                case "Yellow":
                    this.ForeColor = Color.Yellow;
                    break;
            }
        }

        private void time_label_Click(object sender, EventArgs e)
        {

        }

        private void clear_button_Click(object sender, EventArgs e) //Clears text received
        {
            textBox2.Text = "";
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e) //Disables tempo if pattern mode is selected
        {
            if (comboBox4.Text == "Tempo/BPM")
            {
                numericUpDown1.Enabled = true;
            }
            else
            {
                numericUpDown1.Enabled = false;
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e) //Metronome click
        {
            if (max_hits > 0)
            {
                Console.Beep(4000, 100);
                max_hits = max_hits - 1;
            }
            else
            {
                timer2.Stop();
            }
        }

        private void showData(object sender, EventArgs e)
        {
            textBox2.Text += dataIn;
        }

        private void timer1_Tick(object sender, EventArgs e) //Countdown timer
        {
            if (bpm == "n")
            {
                if (time_left > 1)
                {
                    time_left = time_left - 1;
                    time_label.Text = " Pattern Mode";
                }
                else
                {
                    timer1.Stop();
                    time_label.Text = "Session is over!";
                    sendButton.Enabled = true;
                }
            }
            else
            {
                if (time_left > 1)
                {
                    time_left = time_left - 1;
                    time_label.Text = time_left + " seconds";
                }
                else
                {
                    timer1.Stop();
                    time_label.Text = "Session is over!";
                    sendButton.Enabled = true;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e) //Show or Hide settings button
        {
            string value1 = button1.Text;
            switch (value1)
            {
                case "Settings >":
                    panel3.Visible = true;
                    break;
                case "Settings <":
                    panel3.Visible = false;
                    break;
            }
            button1.Text = "Settings <";
            if (panel3.Visible == true)
            {
                button1.Text = "Settings <";
            }
            else if (panel3.Visible == false)
            {
                button1.Text = "Settings >";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
