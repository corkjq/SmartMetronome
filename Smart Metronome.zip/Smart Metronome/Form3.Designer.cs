﻿namespace Smart_Metronome
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonToForm1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonToForm1
            // 
            this.buttonToForm1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonToForm1.Location = new System.Drawing.Point(144, 425);
            this.buttonToForm1.Name = "buttonToForm1";
            this.buttonToForm1.Size = new System.Drawing.Size(215, 42);
            this.buttonToForm1.TabIndex = 0;
            this.buttonToForm1.Text = "Practice";
            this.buttonToForm1.UseVisualStyleBackColor = true;
            this.buttonToForm1.Click += new System.EventHandler(this.buttonToForm1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(423, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome to the Smart Metronome";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImage = global::Smart_Metronome.Properties.Resources.snare;
            this.ClientSize = new System.Drawing.Size(501, 538);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonToForm1);
            this.Name = "Form3";
            this.Text = "Smart Metronome";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonToForm1;
        private System.Windows.Forms.Label label1;
    }
}